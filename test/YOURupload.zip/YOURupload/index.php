<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.js"></script>
<script type="text/javascript" src="js/jquery.uploadProgress.js"></script>


<script type="text/javascript">
$(function() {
    $('form').uploadProgress({
		/* scripts locations for safari */
		jqueryPath: "https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.js",
		uploadProgressPath: "js/jquery.uploadProgress.js",
    /* function called each time bar is updated */
		uploading: function(upload) {$('#percents').html(upload.percents+'%');},
		/* selector or element that will be updated */
		progressBar: "#progressbar",
		/* progress reports url */
		progressUrl: "../progress",
    /* how often will bar be updated */
		interval: 2000
    });
});
</script>
<style>
  .bar {
    width: 300px;
  }
  
  #progress {
    background: #eee;
    border: 1px solid #222;
    margin-top: 20px;
  }
  #progressbar {
    width: 0px;
    height: 24px;
    background: #333;
  }
</style>
<?php 
session_start();
echo "test";
  print_r( $_SESSION['uploadForm'] );
?>
    <form id="upload" enctype="multipart/form-data" action="/upload/" method="post">
        <input name='upload_origin' type='hidden' value='/YOURupload/index.php'/>
        <input name="file" type="file"/>
        <input type="submit" value="Upload"/>
      </form>
		
      <div id="uploading">
        <div id="progress" class="bar">
          <div id="progressbar">&nbsp;</div>
          <div id="percents"></div>
        </div>
      </div>
      
      

<!---<form id="javascript-upload" action="/upload/" enctype="multipart/form-data" method="post">
  <label for="jfile">File Upload:
    <input id="jfile" name="file" type="file" />
  </label>
  <input type="submit" value="Upload File" />
</form>
<div style="border: 1px solid black; width: 300px;">
  <div id="progressbar" style="background-color: #D3DCE3; width: 0px; height: 12px; margin: 1px;"></div>
</div>
<div id="percents">
</div>-->
