<?PHP

session_start();
$_SESSION['uploadForm'] = $_POST;

header('Location: '. $_POST['upload_origin'] );


